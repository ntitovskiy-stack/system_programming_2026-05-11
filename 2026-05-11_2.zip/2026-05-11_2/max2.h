#ifndef __MAX2__
#define __MAX2__

int max2(int,int);

#endif
