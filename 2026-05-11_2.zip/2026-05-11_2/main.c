#include <stdio.h>
#include "max2.h"
#include "max3.h"

int main(void)
{
	int a, b, c;
	printf("Input value a: ");
	scanf("%d", &a);
	printf("Input value b: ");
	scanf("%d", &b);
	printf("Input value c: ");
	scanf("%d", &c);
	printf("max2=%d\nmax3=%d\n", max2(a, b), max3(a, b, c));
	return 0;
}
