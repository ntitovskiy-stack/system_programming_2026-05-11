#ifndef __MAX3__
#define __MAX3__

int max3(int,int,int);

#endif
