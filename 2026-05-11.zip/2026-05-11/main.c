#include <stdio.h>
#include "sum.h"
#include "sub.h"

int main(void)
{
	int a, b;
	scanf("%d%d", &a, &b);
	printf("sum=%d\nsub=%d\n", sum(a, b), sub(a, b));
	return 0;
}
