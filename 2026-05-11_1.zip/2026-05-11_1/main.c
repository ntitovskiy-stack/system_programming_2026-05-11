#include <stdio.h>
#include "sum.h"
#include "sub.h"

int main(void)
{
	int a, b;
	printf("Input value a: ");
	scanf("%d", &a);
	printf("Input value b: ");
	scanf("%d", &b);
	int c;
	printf("Menu:\n0 - sum(a,b)\n1 - sub(a,b)\nChoose func: ");
	scanf("%d", &c);
	switch(c){
	case 0:
		printf("sum=%d\n", sum(a,b));
		break;
	case 1:
		printf("sub=%d\n", sub(a,b));
		break;
	default:
		printf("Incorrect value\n");
	}
	return 0;
}
